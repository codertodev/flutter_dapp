abstract class PayableAccountBase {
  String publicKey;
  String asset;

  PayableAccountBase(this.publicKey, this.asset);

  Future<BigInt> balance();
}