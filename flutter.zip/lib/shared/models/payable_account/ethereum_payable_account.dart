import 'package:flutter_dapp/shared/models/erc20_token/erc20_token.dart';
import 'package:flutter_dapp/shared/models/payable_account/payable_account_base.dart';
import 'package:flutter_dapp/shared/providers/network_provider.dart';
import 'package:web3dart/credentials.dart';

class EthereumPayableAccount extends PayableAccountBase {

  final network = NetworkProvider.instance;

  EthereumPayableAccount(String publicKey, String asset) : super(publicKey, asset);

  @override
  Future<BigInt> balance() async {
    Erc20Token erc20token = Erc20Token(asset, network);
    return await erc20token.balanceOf(EthereumAddress.fromHex(publicKey));
  }

}