import 'package:flutter_dapp/shared/models/wallet/wallet_base.dart';

class InternalWallet extends WalletBase {
  
}