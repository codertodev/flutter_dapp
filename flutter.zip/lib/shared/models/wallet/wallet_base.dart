
import 'package:flutter_dapp/shared/models/erc20_token/erc20_token.dart';
import 'package:flutter_dapp/shared/models/payable_account/ethereum_payable_account.dart';
import 'package:flutter_dapp/shared/models/payable_account/payable_account_base.dart';


abstract class WalletBase {
  String encryptedMnemonic;
  String encryptedPrivateKey;
  List<PayableAccountBase> accounts = [EthereumPayableAccount("0xeeca957c871256440deb6ca9a192f2769c6f721f", "0xc544f0b5C0259172b6D6a1f6394aB21B5fd8F4Bf")];

  PayableAccountBase getDefaultAccount() {
    return accounts.first;
  }

  PayableAccountBase getAccount(String asset) {
    return accounts.firstWhere((element) => element.asset == asset);
  }

  Future<BigInt> balance(String asset) async {
    return await getAccount(asset).balance();
  }
}